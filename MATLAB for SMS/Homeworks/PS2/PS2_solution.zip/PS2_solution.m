clear all
% close all


cd 'C:\Dropbox\matlab course\m-files'
load 'problem_set_2.mat'


% Assign Variables
acc = traces(42).acc;
don = traces(42).don;
x = traces(42).x;
ba = traces(42).ba;
bd = traces(42).bd;
acq_time = traces(42).acq_time;

% Bin up
bintime = 0.01;
bin_factor = bintime/acq_time;
numbins = floor(numel(acc)/bin_factor);

accbin = sum(reshape(acc(1:bin_factor*numbins),bin_factor,numbins));
donbin = sum(reshape(don(1:bin_factor*numbins),bin_factor,numbins));


% Background correct
accbin_bck = accbin - bin_factor*ba;
donbin_bck = donbin - bin_factor*bd;

% Crosstalk correct
num_x = (x/(1-x))*(donbin_bck - bin_factor*bd);

acc_correct = accbin_bck - num_x;
don_correct = donbin_bck + num_x;

% Calculate efficiency
efficiency = acc_correct ./ (acc_correct + don_correct);

% Efficiency histogram
e = 0:0.01:1.1;
e_hist = hist(efficiency,e);
e_hist = e_hist/sum(e_hist);


% Figure
t = bintime*(1:numel(accbin));

figure('papersize',[4 6],'visible','off'); orient tall

subplot(3,4,1:4); 
hold on;

plot(t,accbin,'r',t,donbin,'b')
set(gca,'fontsize',10,'fontname','times new roman')
axis([t(1) t(end) 0 max([accbin donbin])])
xlabel('xlabel','fontsize',18)


text(0.9,0.1,['ba = ' num2str(ba)],'units','normalized','horizontalalignment','right')
text(0.8,0.8,['bd = ' num2str(bd)],'units','normalized')
text(0.8,0.7,['x = ' num2str(x)],'units','normalized')


subplot(3,4,5:8); plot(t,efficiency,'r')
axis([t(1) t(end) 0 1.1]) 


subplot(3,4,10:11); bar(e,e_hist)%,'b',1)
axis([0 1.1 0 1.1*max(e_hist)]) 
text(0.8,0.9,['\mu = ' num2str(mean(efficiency))],'units','normalized')
text(0.8,0.8,['\sigma = ' num2str(std(efficiency))],'units','normalized')


print 'demo.pdf' -dpdf


print 'demo.tif' -dtiff -r300

% print('demo.pdf','-dpdf')


