clear all
close all

addpath 'C:\Users\Nick\Dropbox\matlab course\m-files'
% savepath

tree_plot = true;
detail_plot = true;
denoise_plot = true;

%% signal
N = 450;
s = normrnd(100,15,1,N);
spad = mean(s)*ones(1,2^(nextpow2(N))-N);
Npad = 2^nextpow2(N);
S = [s spad];
S_hat = fft(S,1024);


%% filters
[phi psi] = wfilters('haar');
wpad = zeros(1,Npad-numel(phi));
phi_pad = [phi wpad];
psi_pad = [psi wpad];

phi_hat = fft(phi_pad,1024);
psi_hat = fft(psi_pad,1024);


%% level 1
a1 = ifft(S_hat.*phi_hat,1024);
a1 = a1(1:512);
a1 = a1(2:2:end);

d1 = ifft(S_hat.*psi_hat,1024);
d1 = d1(1:512);
d1 = d1(2:2:end);


%% level 2
wpad2 = zeros(1,numel(a1)-numel(phi));
phi_pad2 = [phi wpad2]; phi_hat2 = fft(phi_pad2,512);
psi_pad2 = [psi wpad2]; psi_hat2 = fft(psi_pad2,512);

a1_hat = fft(a1,512);

a2 = ifft(a1_hat.*phi_hat2,512);
a2 = a2(1:256);
a2 = a2(2:2:end);

d2 = ifft(a1_hat.*psi_hat2,512);
d2 = d2(1:256);
d2 = d2(2:2:end);


%% level 3
wpad3 = zeros(1,numel(a2)-numel(phi));
phi_pad3 = [phi wpad3]; phi_hat3 = fft(phi_pad3,256);
psi_pad3 = [psi wpad3]; psi_hat3 = fft(psi_pad3,256);

a2_hat = fft(a2,256);

a3 = ifft(a2_hat.*phi_hat3,256);
a3 = a3(1:128);
a3 = a3(2:2:end);

d3 = ifft(a2_hat.*psi_hat3,256);
d3 = d3(1:128);
d3 = d3(2:2:end);

t0 = 0.01*(1:Npad);
t1 = t0(2:2:end);
t2 = t1(2:2:end);
t3 = t2(2:2:end);

%% threshold
sigma = sqrt(mean(S));
thresh = sigma*sqrt(2*log(N));

%% hard threshold
d1_hard = d1;
d1_hard(d1_hard <= thresh) = 0;

d2_hard = d2;
d2_hard(d2_hard <= thresh) = 0;

d3_hard = d3;
d3_hard(d3_hard <= thresh) = 0;

%% soft threshold
d1_soft = d1;
d1_soft = sign(d1_soft).*max(abs(d1_soft) - thresh,0);

d2_soft = d2;
d2_soft = sign(d2_soft).*max(abs(d2_soft) - thresh,0);

d3_soft = d3;
d3_soft = sign(d3_soft).*max(abs(d3_soft) - thresh,0);

%% reconstruct
psi = fliplr(psi);

%% level 3 --> level 2

% phi and psi
wpad_up2 = zeros(1,numel(a2)-numel(phi));
phi_up2 = [phi wpad_up2]; phi_hat_up2 = fft(phi_up2,256);
psi_up2 = [psi wpad_up2]; psi_hat_up2 = fft(psi_up2,256);

% upsample
a3_up = reshape([a3; zeros(size(a3))],1,2*numel(a3));
d3_up_hard = reshape([d3_hard; zeros(size(a3))],1,2*numel(a3));
d3_up_soft = reshape([d3_soft; zeros(size(a3))],1,2*numel(a3));

% FTs
a3_up_hat = fft(a3_up,256);
d3_up_hard_hat = fft(d3_up_hard,256);
d3_up_soft_hat = fft(d3_up_soft,256);

% convolutions
a3_conv = ifft(a3_up_hat.*phi_hat_up2,256);
a3_conv = a3_conv(1:128);

d3_hard_conv = ifft(d3_up_hard_hat.*psi_hat_up2,256);
d3_hard_conv = d3_hard_conv(1:128);

d3_soft_conv = ifft(d3_up_soft_hat.*psi_hat_up2,256);
d3_soft_conv = d3_soft_conv(1:128);

% reconstructed
r2_hard = a3_conv + d3_hard_conv;
r2_soft = a3_conv + d3_soft_conv;


%% level 2 --> level 1

% phi and psi
wpad_up1 = zeros(1,numel(a1)-numel(phi));
phi_up1 = [phi wpad_up1]; phi_hat_up1 = fft(phi_up1,512);
psi_up1 = [psi wpad_up1]; psi_hat_up1 = fft(psi_up1,512);

% upsample
r2_up_hard = reshape([r2_hard; zeros(size(r2_hard))],1,2*numel(r2_hard));
r2_up_soft = reshape([r2_soft; zeros(size(r2_hard))],1,2*numel(r2_hard));
d2_up_hard = reshape([d2_hard; zeros(size(r2_hard))],1,2*numel(r2_hard));
d2_up_soft = reshape([d2_soft; zeros(size(r2_hard))],1,2*numel(r2_hard));

% FTs
r2_up_hard_hat = fft(r2_up_hard,512);
r2_up_soft_hat = fft(r2_up_soft,512);
d2_up_hard_hat = fft(d2_up_hard,512);
d2_up_soft_hat = fft(d2_up_soft,512);

% convolutions
r2_hard_conv = ifft(r2_up_hard_hat.*phi_hat_up1,512);
r2_hard_conv = r2_hard_conv(1:256);

r2_soft_conv = ifft(r2_up_soft_hat.*phi_hat_up1,512);
r2_soft_conv = r2_soft_conv(1:256);

d2_hard_conv = ifft(d2_up_hard_hat.*psi_hat_up1,512);
d2_hard_conv = d2_hard_conv(1:256);

d2_soft_conv = ifft(d2_up_soft_hat.*psi_hat_up1,512);
d2_soft_conv = d2_soft_conv(1:256);

% reconstructed
r1_hard = r2_hard_conv + d2_hard_conv;
r1_soft = r2_soft_conv + d2_soft_conv;


%% level 1 --> level 0

% phi and psi
wpad_up = zeros(1,numel(S)-numel(phi));
phi_up = [phi wpad_up]; phi_hat_up = fft(phi_up,1024);
psi_up = [psi wpad_up]; psi_hat_up = fft(psi_up,1024);

% upsample
r1_up_hard = reshape([r1_hard; zeros(size(r1_hard))],1,2*numel(r1_hard));
r1_up_soft = reshape([r1_soft; zeros(size(r1_hard))],1,2*numel(r1_hard));
d1_up_hard = reshape([d1_hard; zeros(size(r1_hard))],1,2*numel(r1_hard));
d1_up_soft = reshape([d1_soft; zeros(size(r1_hard))],1,2*numel(r1_hard));

% FTs
r1_up_hard_hat = fft(r1_up_hard,1024);
r1_up_soft_hat = fft(r1_up_soft,1024);
d1_up_hard_hat = fft(d1_up_hard,1024);
d1_up_soft_hat = fft(d1_up_soft,1024);

% convolutions
r1_hard_conv = ifft(r1_up_hard_hat.*phi_hat_up,1024);
r1_hard_conv = r1_hard_conv(1:512);

r1_soft_conv = ifft(r1_up_soft_hat.*phi_hat_up,1024);
r1_soft_conv = r1_soft_conv(1:512);

d1_hard_conv = ifft(d1_up_hard_hat.*phi_hat_up,1024);
d1_hard_conv = d1_hard_conv(1:512);

d1_soft_conv = ifft(d1_up_soft_hat.*phi_hat_up,1024);
d1_soft_conv = d1_soft_conv(1:512);

% reconstructed
r0_hard = r1_hard_conv + d1_hard_conv;
r0_soft = r1_soft_conv + d1_soft_conv;

%% remove pad
r0_hard = r0_hard(1:N);
r0_soft = r0_soft(1:N);
t = 0.01*(1:N);

%% stats
usig = 0.01*round(100*mean(s));
uhard = 0.01*round(100*mean(r0_hard));
usoft = 0.01*round(100*mean(r0_soft));

ssig = 0.01*round(100*std(s));
shard = 0.01*round(100*std(r0_hard));
ssoft = 0.01*round(100*std(r0_soft));


%% tree plot
if tree_plot
    figure('papersize',[8.5 11]); orient tall

    subplot(4,2,1:2); plot(t0,S,'r'); 
    axis([t0(1) t0(end) 0 max(S)]);
    xlabel('time'); ylabel('S(t)')

    subplot 423; plot(t1,a1,'b'); 
    axis([t0(1) t0(end) 0 max(a1)]);
    xlabel('time'); ylabel('a_1(t)')

    subplot 424; plot(t1,d1,'color',[0 0.5 0]); 
    axis([t0(1) t0(end) min(d1) max(d1)]);
    xlabel('time'); ylabel('d_1(t)')

    subplot 425; plot(t2,a2,'b'); 
    axis([t0(1) t0(end) 0 max(a2)]);
    xlabel('time'); ylabel('a_2(t)')

    subplot 426; plot(t2,d2,'color',[0 0.5 0]); 
    axis([t0(1) t0(end) min(d2) max(d2)])
    xlabel('time'); ylabel('d_2(t)')

    subplot 427; plot(t3,a3,'b'); 
    axis([t0(1) t0(end) 0 max(a3)]);
    xlabel('time'); ylabel('a_3(t)')

    subplot 428; plot(t3,d3,'color',[0 0.5 0]); 
    axis([t0(1) t0(end) min(d3) max(d3)]);
    xlabel('time'); ylabel('d_3(t)')
    
    cd 'C:\Users\Nick\Dropbox\matlab course\completed HW'
    print 'PS4_tree_plot.pdf' '-dpdf'
    close all
end


%% detail plot
if detail_plot
    figure('papersize',[8.5 11]); orient tall

    subplot 311; hold on;
    plot(t1,d1,'color',[0 0.5 0])
    plot(t1,d1_hard,'color',[1 0.5 0])
    plot(t1,d1_soft,'b')
    plot(t1,thresh*ones(size(t1)),'--k')
    plot(t1,-thresh*ones(size(t1)),'--k')
    axis([t1(1) t1(end) 1.1*min(d1) 1.1*max(d1)])
    xlabel('time'); ylabel('d_(t)')
    legend('raw','hard','soft')

    subplot 312; hold on;
    plot(t2,d2,'color',[0 0.5 0])
    plot(t2,d2_hard,'color',[1 0.5 0])
    plot(t2,d2_soft,'b')
    plot(t2,thresh*ones(size(t2)),'--k')
    plot(t2,-thresh*ones(size(t2)),'--k')
    axis([t0(1) t0(end) 1.1*min(d2) 1.1*max(d2)])
    xlabel('time'); ylabel('d_2(t)')
    legend('raw','hard','soft')

    subplot 313; hold on;
    plot(t3,d3,'color',[0 0.5 0])
    plot(t3,d3_hard,'color',[1 0.5 0])
    plot(t3,d3_soft,'b')
    plot(t3,thresh*ones(size(t3)),'--k')
    plot(t3,-thresh*ones(size(t3)),'--k')
    axis([t0(1) t0(end) 1.1*min(d3) 1.1*max(d3)])
    xlabel('time'); ylabel('d_3(t)')
    legend('raw','hard','soft')
    
    cd 'C:\Users\Nick\Dropbox\matlab course\completed HW'
    print 'PS4_detail_plot.pdf' '-dpdf'
    close all
end

%% denoise plot
if denoise_plot
    figure('papersize',[11 8.5]); orient tall
    hold on;
    plot(t,s,'--','color',[0.6 0.6 0.6])
    plot(t,r0_hard,'color',[1 0.5 0],'linewidth',1.5)
    plot(t,r0_soft,'color',[0 0.5 0],'linewidth',1.5)
    set(gca,'box','on')
    axis([t(1) t(end) 0 max(s)])
    legend('signal','hard threshold','soft threshold')
    
    % tabulate mu's and sigmas    
    text(0.7,0.4,'signal','units','normalized','horizontalalignment','center','fontsize',10,'fontweight','bold')
    text(0.8,0.4,'hard','units','normalized','horizontalalignment','center','fontsize',10,'fontweight','bold')
    text(0.9,0.4,'soft','units','normalized','horizontalalignment','center','fontsize',10,'fontweight','bold')
    
    text(0.65,0.3,'\mu','units','normalized','horizontalalignment','center','fontsize',12,'fontweight','bold')
    text(0.65,0.2,'\sigma','units','normalized','horizontalalignment','center','fontsize',12,'fontweight','bold')

    text(0.7,0.3,num2str(usig),'units','normalized','horizontalalignment','center','fontsize',10)
    text(0.8,0.3,num2str(uhard),'units','normalized','horizontalalignment','center','fontsize',10)
    text(0.9,0.3,num2str(usoft),'units','normalized','horizontalalignment','center','fontsize',10)
    
    text(0.7,0.2,num2str(ssig),'units','normalized','horizontalalignment','center','fontsize',10)
    text(0.8,0.2,num2str(shard),'units','normalized','horizontalalignment','center','fontsize',10)
    text(0.9,0.2,num2str(ssoft),'units','normalized','horizontalalignment','center','fontsize',10)
    
    
    cd 'C:\Users\Nick\Dropbox\matlab course\completed HW'
    print 'PS4_denoise_plot.pdf' '-dpdf'
end
    
    
    
    
