
clear all
close all


a = 1;
k = -1e-1;
x = 0:0.1:25;
y = a*exp(k*x);
y = y + 0.1*randn(size(y));

model_fun = 'a*exp(k*x)';
coefs = {'a','k'};
exp_model = fittype(model_fun,'coefficients',coefs,'independent','x');

[cfun,gof] = fit(x(:),y(:),exp_model);  % no quotes for a fittype model!
model_coefs = coeffvalues(cfun);

model_fit = model_coefs(1)*exp(model_coefs(2)*x);

plot(x,y,x,model_fit)