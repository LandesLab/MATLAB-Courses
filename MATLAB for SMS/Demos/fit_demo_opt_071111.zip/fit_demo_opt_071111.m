function out = fit_demo_opt_071111(X,x)

cfun = fit(x(:),X(:),'gauss1');
X_0 = coeffvalues(cfun);

% X_0 = [1 1];

opts = optimset('display','off',...             % displays information 
                'funvalcheck','off',...         % displays error message if wsse returns Inf or NaN
                'maxfunevals',1e10,...          % there are multiple function evaluations
                'maxiter',1e8,...               % per fminsearch iteration
                'tolx',1e-10,...                % if the parameters change by < tolx, or if
                'tolfun',1e-10);                % the wsse changes by < tolfun, fminsearch is convergent (and exits...)



out = fminsearch(@weighted_sse_FCS,X_0,opts);

function sse = weighted_sse_FCS(X_0)
    X_fit = X_0(1)*exp(-((x - X_0(2)).^2)/(2*X_0(3)^2));
    residuals = X_fit - X;
    sse = sum(residuals.^2);
end

end