clear all
close all



% time + frequency
t = 0.1*(1:1024);
s = normrnd(81,sqrt(81),size(t));
s_hat = fft(s,1024); s_hat = s_hat(2:512);
f = (2:512)*100/1024;
p_s = real(s_hat).^2 + imag(s_hat).^2;

% figure('papersize',[7 3]); orient tall;
% figure
% subplot 211; plot(t,s,'linewidth',1); 
% axis([0 100 0 max(s)]);
% xlabel('time'); ylabel('s(t)')
% 
% subplot 212; plot(f,p_s,'linewidth',1.5,'color',[0 0.5 0]); 
% axis([f(1) f(end) 0 max(p_s)]); 
% grid on;
% xlabel('f (Hz)'); ylabel('p_s')


% Time-frequency localization
w = linspace(-1,1,1024);
wndw = 1 - abs(w);%triang(1024);
% wndw = wndw';
wndws = zeros(32,1024);
for k = 1:16
    wndws(k,:) = max(s)*[zeros(1,64*(16-k)) wndw(1:1024-64*(16-k))];
end    
for k = 1:16
    j = k + 16;
    wndws(j,:) = max(s)*[wndw((64*(k-1)+1):1024) zeros(1,64*(k-1))];
end    


% figure
% for k = 1:32 
%     plot(t,s,'--r',t,wndws(k,:),'b','linewidth',1.5); 
%     axis([0 100 0 1.1*max(s)])
%     pause(0.4); 
% end



% Haar scaling and wavelet functions
x = [-1 -0.5 0 0 0.5 0.5 0.5 1 1 1.5 2];
phi = [zeros(1,3) ones(1,numel(x)-6) zeros(1,3)];
psi = [zeros(1,3) 1 1 0 -1 -1 zeros(1,3)];

% figure('papersize',[7 3]); orient tall;
% figure
% subplot 121; plot(x,phi,'linewidth',1.5); 
% axis([-1 2 -1.2 1.2]);
% xlabel('x'); ylabel('\phi')
% 
% subplot 122; plot(x,psi,'linewidth',1.5,'color',[0 0.5 0]); 
% axis([-1 2 -1.2 1.2]); xlabel('x'); ylabel('\psi')
% 


% haar in frequency space
clear phi psi
[phi psi] = wfilters('haar');

phi_hat = fft(phi,128); phi_hat = (phi_hat(1:64));
phi_amp = sqrt(real(phi_hat).^2 + imag(phi_hat).^2);

psi_hat = fft(psi,128); psi_hat = (psi_hat(1:64));
psi_amp = sqrt(real(psi_hat).^2 + imag(psi_hat).^2);

f_wav = (1:64)*100/128;

% figure
% subplot 121; plot(f_wav,phi_amp,'b','linewidth',1.5); 
% axis([f(1) f(end) 0 1.5]);
% xlabel('f (Hz)'); ylabel('\phi(\omega)')
% set(gca,'xtick',[12.5 25 37.5 50],'xticklabel',{'','fs/4','','fs/2'})
% grid on;
% 
% subplot 122; plot(f_wav,psi_amp,'linewidth',1.5,'color',[0 0.5 0]); 
% axis([f(1) f(end) 0 1.5]); xlabel('x'); ylabel('\psi(\omega)')
% set(gca,'xtick',[12.5 25 37.5 50],'xticklabel',{'','fs/4','','fs/2'})
% grid on;



% MRA: approximations and details
pad = zeros(1,numel(s)-numel(phi));
phi_pad = [phi pad];
psi_pad = [psi pad];

% level 1
a1 = conv(s,phi_pad);
a1 = a1(1:numel(s));
a1 = a1(2:2:end);

d1 = conv(s,psi_pad);
d1 = d1(1:numel(s));
d1 = d1(2:2:end);

% level 2
pad2 = zeros(1,numel(a1)-numel(phi));
phi_pad2 = [phi pad2];
psi_pad2 = [psi pad2];

a2 = conv(a1,phi_pad2);
a2 = a2(1:numel(a1));
a2 = a2(2:2:end);

d2 = conv(a1,psi_pad2);
d2 = d2(1:numel(a1));
d2 = d2(2:2:end);

t1 = t(2:2:end);
t2 = t1(2:2:end);

figure
subplot(3,2,1:2); plot(t,s,'b');
axis([t(1) t(end) 0 max(s)])

subplot 323; plot(t1,a1,'r');
axis([t1(1) t1(end) 0 max(a1)])

subplot 324; plot(t1,d1,'color',[0 0.5 0]);
axis([t1(1) t1(end) min(d1) max(d1)])

subplot 325; plot(t2,a2,'r');
axis([t2(1) t2(end) 0 max(a2)])

subplot 326; plot(t2,d2,'color',[0 0.5 0]);
axis([t2(1) t2(end) min(d2) max(d2)])



thresh = sqrt(2*log(1024)*mean(s));
% soft threshold
d1_t = d1;
d2_t = d2;

d1_t(d1_t <= thresh) = 0;
d2_t(d2_t <= thresh) = 0;
% d1_t(d1_t > thresh) = sign(d1_t(d1_t > thresh))*(abs(d1_t(d1_t > thresh)) - thresh);




% reconstruct
r1 = conv(reshape([a2; zeros(size(a2))],1,2*numel(a2)),phi) + ...
    conv(reshape([d2_t; zeros(size(a2))],1,2*numel(a2)),psi);
r1(end) = [];

r = conv(reshape([r1; zeros(size(a1))],1,2*numel(a1)),phi) + ...
    conv(reshape([d1_t; zeros(size(a1))],1,2*numel(a1)),psi);
r(end) = [];

close all
plot(t,s,t,r)




